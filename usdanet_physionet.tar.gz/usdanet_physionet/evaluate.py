import argparse, os, yaml, json, pandas as pd


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--results",required=True); args=ap.parse_args()
    with open(os.path.join(args.results,"summary.json")) as f: s=json.load(f)
    print(json.dumps(s,indent=2))
    df=pd.read_csv(os.path.join(args.results,"loso_results.csv"))
    print("\nWorst subjects:")
    print(df.sort_values("accuracy")[['subject','accuracy','balanced_accuracy','macro_f1','kappa']].head(10).to_string(index=False))
    print("\nBest subjects:")
    print(df.sort_values("accuracy",ascending=False)[['subject','accuracy','balanced_accuracy','macro_f1','kappa']].head(10).to_string(index=False))

if __name__=="__main__": main()
