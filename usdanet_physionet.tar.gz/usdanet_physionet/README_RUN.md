# Exact commands

1. Edit `configs/physionet.yaml`:

```yaml
data_root: "/absolute/path/to/your/EEGMMIDB"
```

2. Test dependencies and discovery:

```bash
python train.py --config configs/physionet.yaml --max_subjects 3 --epochs 2
```

3. Run a small sanity experiment:

```bash
python train.py --config configs/physionet.yaml --max_subjects 8 --epochs 10
```

4. Run full LOSO:

```bash
python train.py --config configs/physionet.yaml --epochs 60
```

5. Inspect summary:

```bash
python evaluate.py --results ./runs/usdanet_physionet
```

## macOS Apple Silicon
The code automatically uses MPS when available only if you modify the device selection in `train.py`. For maximum compatibility, CUDA is selected first. CPU works but will be much slower for the full 109-subject experiment.
