import argparse
import os
import sys
import yaml
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.utils.class_weight import compute_class_weight
from tqdm import tqdm
import matplotlib.pyplot as plt
import seaborn as sns

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from src.utils import set_seed, ensure_dir, save_json, count_parameters
from src.data import discover_edf, load_subject, EEGDataset
from src.model import USDAClassifier
from src.engine import save_checkpoint
from src.metrics import compute_metrics
from src.losses import prototype_loss, supervised_contrastive_loss
import torch.nn.functional as F


class DomainDataset(Dataset):
    def __init__(self, base_dataset, domain_ids):
        self.base=base_dataset; self.domain_ids=torch.as_tensor(domain_ids,dtype=torch.long)
    def __len__(self): return len(self.base)
    def __getitem__(self,i):
        x,y=self.base[i]
        return x,y,self.domain_ids[i]


def _make_pack(subject_ids, all_data):
    X=np.concatenate([all_data[s].X for s in subject_ids],axis=0)
    y=np.concatenate([all_data[s].y for s in subject_ids],axis=0)
    ss=np.concatenate([all_data[s].subject_ids for s in subject_ids],axis=0)
    return type("Pack",(),{"X":X,"y":y,"subject_ids":ss})


def _fit_norm(X):
    med=np.median(X,axis=(0,2),keepdims=True)
    q25=np.percentile(X,25,axis=(0,2),keepdims=True)
    q75=np.percentile(X,75,axis=(0,2),keepdims=True)
    scale=np.maximum(q75-q25,1e-6)
    return med.astype(np.float32), scale.astype(np.float32)


def _build_model(cfg, num_domains, device):
    model=USDAClassifier(
        num_channels=cfg["num_channels"], num_classes=3, num_domains=num_domains,
        stem=cfg["stem_channels"], temp=cfg["temporal_channels"], fusion=cfg["fusion_channels"],
        emb=cfg["embedding_dim"], heads=cfg["transformer_heads"], layers=cfg["transformer_layers"],
        ffn=cfg["transformer_ffn"], dropout=cfg["dropout"]
    ).to(device)
    return model


def _make_domain_loader(pack, domain_subjects, cfg, med, scale):
    X=((pack.X-med)/scale).astype(np.float32)
    y=pack.y.astype(np.int64)
    dmap={str(s):i for i,s in enumerate(domain_subjects)}
    d=np.asarray([dmap[str(s)] for s in pack.subject_ids],dtype=np.int64)
    ds=EEGDataset(X,y,augment=True,cfg=cfg)
    domds=DomainDataset(ds,d)
    dl=DataLoader(domds,batch_size=cfg["batch_size"],shuffle=True,num_workers=cfg["num_workers"],
                  pin_memory=cfg["pin_memory"],drop_last=True,persistent_workers=cfg["num_workers"]>0)
    return dl


def _make_eval_loader(pack, cfg, med, scale):
    X=((pack.X-med)/scale).astype(np.float32)
    ds=EEGDataset(X,pack.y.astype(np.int64),augment=False,cfg=cfg)
    dl=DataLoader(ds,batch_size=cfg["batch_size"],shuffle=False,num_workers=cfg["num_workers"],
                  pin_memory=cfg["pin_memory"],persistent_workers=cfg["num_workers"]>0)
    return dl


def _predict(model, loader, device):
    model.eval(); yall=[]; pall=[]
    with torch.no_grad():
        for xb,yb in loader:
            xb=xb.to(device,non_blocking=True)
            logits=model(xb,0)["logits"]
            yall.extend(yb.numpy()); pall.extend(logits.argmax(1).cpu().numpy())
    return compute_metrics(np.asarray(yall),np.asarray(pall)), np.asarray(yall), np.asarray(pall)


def _train_one_model(train_pack, train_subjects, val_pack, cfg, device, verbose_prefix=""):
    med,scale=_fit_norm(train_pack.X)
    tr_dl=_make_domain_loader(train_pack,train_subjects,cfg,med,scale)
    val_dl=_make_eval_loader(val_pack,cfg,med,scale) if val_pack is not None else None
    model=_build_model(cfg,len(train_subjects),device)
    optimizer=torch.optim.AdamW(model.parameters(),lr=cfg["lr"],weight_decay=cfg["weight_decay"],betas=(0.9,0.99))
    total_epochs=int(cfg["pretrain_epochs"]+cfg["domain_epochs"])
    scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=total_epochs)
    use_amp=device.type=="cuda" and cfg.get("mixed_precision",True)
    scaler=torch.cuda.amp.GradScaler(enabled=use_amp)
    ce=torch.nn.CrossEntropyLoss(label_smoothing=cfg.get("label_smoothing",0.05))
    best=-1.0; best_state=None; history=[]

    for epoch in range(total_epochs):
        model.train(); running=0.; n=0
        if epoch < cfg["pretrain_epochs"]: dlamb=0.0
        else:
            p=(epoch-cfg["pretrain_epochs"]+1)/max(1,cfg["domain_epochs"])
            dlamb=cfg["lambda_domain_max"]*(2/(1+np.exp(-10*p))-1)
        for xb,yb,db in tr_dl:
            xb,yb,db=xb.to(device,non_blocking=True),yb.to(device,non_blocking=True),db.to(device,non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with torch.cuda.amp.autocast(enabled=use_amp):
                out=model(xb,domain_lambda=float(dlamb))
                lcls=ce(out["logits"],yb)
                ldom=F.cross_entropy(out["domain_logits"],db)
                lproto=prototype_loss(out["z"],yb,model.prototypes)
                lcon=supervised_contrastive_loss(out["z"],yb,cfg["supcon_temperature"])
                loss=lcls + dlamb*ldom + cfg["lambda_proto"]*lproto + cfg["lambda_supcon"]*lcon
            scaler.scale(loss).backward(); scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(),cfg["max_grad_norm"])
            scaler.step(optimizer); scaler.update()
            running += loss.item()*len(yb); n += len(yb)
        scheduler.step()
        trloss=running/max(1,n)
        if val_dl is not None:
            valmet,_,_= _predict(model,val_dl,device)
            score=valmet["balanced_accuracy"]
            history.append({"epoch":epoch+1,"loss":trloss,"val_accuracy":valmet["accuracy"],
                            "val_balanced_accuracy":valmet["balanced_accuracy"],"val_macro_f1":valmet["macro_f1"],
                            "val_kappa":valmet["kappa"],"domain_lambda":float(dlamb)})
            print(f"{verbose_prefix} ep {epoch+1:03d}/{total_epochs} loss={trloss:.4f} val_acc={valmet['accuracy']*100:.2f}% val_bal={score*100:.2f}% domλ={dlamb:.3f}",flush=True)
        else:
            score=-trloss
            history.append({"epoch":epoch+1,"loss":trloss,"domain_lambda":float(dlamb)})
        if score>best:
            best=score; best_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
    if best_state: model.load_state_dict(best_state)
    return model, med, scale, history


def train_fold(outer_train_subjects, held_out, all_data, cfg, out_dir, device):
    # Inner validation is subject-disjoint. The outer target subject remains completely untouched.
    if len(outer_train_subjects) < 3:
        raise ValueError("At least 3 source subjects are required for inner subject-level validation.")
    split_n=max(1,int(round(0.20*len(outer_train_subjects))))
    split_n=min(split_n,len(outer_train_subjects)-2)
    rng=np.random.default_rng(cfg["seed"]+int(held_out[1:]))
    shuffled=np.asarray(outer_train_subjects)[rng.permutation(len(outer_train_subjects))].tolist()
    val_subjects=shuffled[:split_n]
    fit_subjects=shuffled[split_n:]
    print(f"[{held_out}] inner fit subjects={len(fit_subjects)} validation subjects={len(val_subjects)}",flush=True)

    fit_pack=_make_pack(fit_subjects,all_data)
    val_pack=_make_pack(val_subjects,all_data)
    target_pack=all_data[held_out]

    # Select epoch using only source validation subjects.
    model,med,scale,history=_train_one_model(fit_pack,fit_subjects,val_pack,cfg,device,verbose_prefix=f"[{held_out}] ")
    selected_epoch=int(history[int(np.argmax([h["val_balanced_accuracy"] for h in history]))]["epoch"])

    # Refit on ALL outer training subjects for exactly the selected number of epochs.
    refit_cfg=dict(cfg)
    refit_cfg["pretrain_epochs"]=min(int(cfg["pretrain_epochs"]),selected_epoch)
    refit_cfg["domain_epochs"]=max(1,selected_epoch-refit_cfg["pretrain_epochs"])
    full_train=_make_pack(outer_train_subjects,all_data)
    final_model,final_med,final_scale,refit_history=_train_one_model(full_train,outer_train_subjects,None,refit_cfg,device,verbose_prefix=f"[{held_out} REFIT] ")

    # Outer target is evaluated exactly once, after model/epoch selection is finished.
    target_loader=_make_eval_loader(target_pack,cfg,final_med,final_scale)
    final,yt,pt=_predict(final_model,target_loader,device)
    final["subject"]=held_out; final["n_params"]=count_parameters(final_model); final["selected_epoch"]=selected_epoch
    final["inner_val_subjects"]=val_subjects; final["fit_subjects_for_selection"]=fit_subjects
    fold_dir=os.path.join(out_dir,held_out); ensure_dir(fold_dir)
    save_json(final,os.path.join(fold_dir,"metrics.json"));
    pd.DataFrame(history).to_csv(os.path.join(fold_dir,"inner_validation_history.csv"),index=False)
    pd.DataFrame(refit_history).to_csv(os.path.join(fold_dir,"refit_history.csv"),index=False)
    if cfg.get("save_best_checkpoint",True):
        torch.save({"model":final_model.state_dict(),"config":cfg,"held_out":held_out,"selected_epoch":selected_epoch,
                    "train_subjects":outer_train_subjects,"normalization_median":final_med,"normalization_iqr":final_scale},
                   os.path.join(fold_dir,"final.pt"))
    if cfg.get("make_plots",True):
        cm=np.asarray(final["confusion_matrix"])
        plt.figure(figsize=(5,4)); sns.heatmap(cm,annot=True,fmt="d",xticklabels=["Left","Right","Feet"],yticklabels=["Left","Right","Feet"])
        plt.xlabel("Predicted");plt.ylabel("True");plt.title(f"LOSO {held_out}");plt.tight_layout();
        plt.savefig(os.path.join(fold_dir,"confusion_matrix.png"),dpi=180);plt.close()
    return final


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--config",required=True); ap.add_argument("--max_subjects",type=int,default=None); ap.add_argument("--epochs",type=int,default=None); ap.add_argument("--folds",nargs="*",default=None); args=ap.parse_args()
    with open(args.config,"r") as f: cfg=yaml.safe_load(f)
    if args.epochs is not None:
        # preserve pretrain/domain ratio; total becomes requested epochs
        pre=int(cfg["pretrain_epochs"]); cfg["domain_epochs"]=max(1,args.epochs-pre)
    if args.max_subjects is not None: cfg["max_subjects"]=args.max_subjects
    if args.folds is not None and len(args.folds): cfg["folds"]=args.folds
    set_seed(cfg["seed"]); ensure_dir(cfg["output_dir"])
    save_json(cfg,os.path.join(cfg["output_dir"],"config.json"))
    device=torch.device("cuda" if torch.cuda.is_available() else ("mps" if torch.backends.mps.is_available() else "cpu"))
    print("Device:",device)
    paths=discover_edf(cfg["data_root"])
    if not paths: raise FileNotFoundError(f"No EDF files found below {cfg['data_root']}")
    subject_ids=list(paths.keys())
    if cfg.get("max_subjects"): subject_ids=subject_ids[:int(cfg["max_subjects"])]
    if cfg.get("folds"): subject_ids=[s for s in subject_ids if s in set(cfg["folds"])]
    print("Subjects:",len(subject_ids),subject_ids[:10])

    all_data={}
    for sid in tqdm(subject_ids,desc="Preparing subjects"):
        all_data[sid]=load_subject(sid,paths[sid],cfg,cfg["cache_dir"])
        u,c=np.unique(all_data[sid].y,return_counts=True); print(sid,"epochs",len(all_data[sid].y),dict(zip(u,c)))

    results=[]
    for held_out in subject_ids:
        train_s=[s for s in subject_ids if s!=held_out]
        nsrc=sum(len(all_data[s].y) for s in train_s)
        print("\n"+"="*80); print("LOSO TARGET:",held_out,"source subjects:",len(train_s),"source epochs:",nsrc,"target:",len(all_data[held_out].y)); print("="*80)
        result=train_fold(train_s,held_out,all_data,cfg,cfg["output_dir"],device)
        results.append(result)
        pd.DataFrame(results).drop(columns=["confusion_matrix"],errors="ignore").to_csv(os.path.join(cfg["output_dir"],"results_so_far.csv"),index=False)

    df=pd.DataFrame(results); df.to_csv(os.path.join(cfg["output_dir"],"loso_results.csv"),index=False)
    summary={"n_subjects":len(df),"mean_accuracy":float(df.accuracy.mean()),"std_accuracy":float(df.accuracy.std(ddof=1) if len(df)>1 else 0),"mean_balanced_accuracy":float(df.balanced_accuracy.mean()),"mean_macro_f1":float(df.macro_f1.mean()),"mean_kappa":float(df.kappa.mean()),"subjects_ge_80pct":int((df.accuracy>=.8).sum())}
    save_json(summary,os.path.join(cfg["output_dir"],"summary.json")); print("\nFINAL SUMMARY"); print(summary)

if __name__=="__main__": main()
