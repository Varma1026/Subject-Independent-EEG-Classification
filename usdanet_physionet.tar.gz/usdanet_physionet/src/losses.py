import torch
import torch.nn.functional as F


def prototype_loss(z, y, prototypes):
    p = F.normalize(prototypes, dim=-1)
    z = F.normalize(z, dim=-1)
    return (1.0 - (z * p[y]).sum(dim=-1)).mean()


def supervised_contrastive_loss(features, labels, temperature=0.15):
    features = F.normalize(features, dim=-1)
    sim = torch.matmul(features, features.t()) / temperature
    n = features.shape[0]
    eye = torch.eye(n, device=features.device, dtype=torch.bool)
    sim = sim.masked_fill(eye, -1e9)
    labels = labels.contiguous().view(-1, 1)
    mask = torch.eq(labels, labels.T).float().to(features.device)
    mask = mask.masked_fill(eye, 0.0)
    log_prob = sim - torch.logsumexp(sim, dim=1, keepdim=True)
    pos_count = mask.sum(dim=1).clamp_min(1.0)
    loss = -(mask * log_prob).sum(dim=1) / pos_count
    valid = (mask.sum(dim=1) > 0)
    return loss[valid].mean() if valid.any() else features.new_tensor(0.0)
