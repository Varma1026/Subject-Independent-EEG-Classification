import os
import numpy as np
import torch
import torch.nn.functional as F
from torch.cuda.amp import autocast, GradScaler
from torch.utils.data import DataLoader
from tqdm import tqdm

from .losses import prototype_loss, supervised_contrastive_loss
from .metrics import compute_metrics
from .utils import ramp_up


def make_loader(dataset, batch_size, shuffle, workers, pin):
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, num_workers=workers,
                      pin_memory=pin, persistent_workers=(workers > 0), drop_last=shuffle)


def run_epoch(model, loader, optimizer, scaler, device, num_epochs_total, epoch, cfg, domain_train=True):
    train = optimizer is not None
    model.train(train)
    total_loss = 0.0; total_n = 0; yall=[]; pall=[]; daccs=[]
    ce_fn = torch.nn.CrossEntropyLoss(label_smoothing=float(cfg.get("label_smoothing", 0.05)))
    dom_lambda = float(cfg.get("lambda_domain_max", 0.5)) * ramp_up(epoch, num_epochs_total, int(cfg.get("pretrain_epochs", 0))) if domain_train else 0.0

    for xb, yb, db in loader:
        xb, yb, db = xb.to(device, non_blocking=True), yb.to(device, non_blocking=True), db.to(device, non_blocking=True)
        if train: optimizer.zero_grad(set_to_none=True)
        with autocast(enabled=(scaler is not None)):
            out = model(xb, domain_lambda=dom_lambda)
            l_cls = ce_fn(out["logits"], yb)
            l_dom = F.cross_entropy(out["domain_logits"], db)
            l_proto = prototype_loss(out["z"], yb, model.prototypes)
            l_con = supervised_contrastive_loss(out["z"], yb, float(cfg.get("supcon_temperature", .15)))
            loss = l_cls + dom_lambda*l_dom + float(cfg.get("lambda_proto", .05))*l_proto + float(cfg.get("lambda_supcon", .1))*l_con
        if train:
            if scaler:
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), float(cfg.get("max_grad_norm", 5.0)))
                scaler.step(optimizer); scaler.update()
            else:
                loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), float(cfg.get("max_grad_norm", 5.0))); optimizer.step()
        total_loss += loss.item()*len(yb); total_n += len(yb)
        pred = out["logits"].argmax(1)
        yall.extend(yb.detach().cpu().numpy()); pall.extend(pred.detach().cpu().numpy())
        daccs.append((out["domain_logits"].argmax(1) == db).float().mean().item())
    met = compute_metrics(np.asarray(yall), np.asarray(pall))
    met.update(loss=total_loss/max(1,total_n), domain_acc=float(np.mean(daccs)), domain_lambda=dom_lambda)
    return met


def evaluate(model, loader, device):
    model.eval(); yall=[]; pall=[]; probs=[]
    with torch.no_grad():
        for xb,yb in loader:
            xb=xb.to(device, non_blocking=True)
            out=model(xb, domain_lambda=0)
            p=torch.softmax(out["logits"],dim=1)
            yall.extend(yb.numpy()); pall.extend(p.argmax(1).cpu().numpy()); probs.append(p.cpu().numpy())
    met=compute_metrics(np.asarray(yall),np.asarray(pall)); met["probs"]=np.concatenate(probs,axis=0)
    return met, np.asarray(yall), np.asarray(pall)


def save_checkpoint(model, optimizer, scheduler, scaler, path, epoch, metrics):
    torch.save({"epoch":epoch,"model":model.state_dict(),"optimizer":optimizer.state_dict() if optimizer else None,
                "scheduler":scheduler.state_dict() if scheduler else None,"scaler":scaler.state_dict() if scaler else None,
                "metrics":metrics}, path)
