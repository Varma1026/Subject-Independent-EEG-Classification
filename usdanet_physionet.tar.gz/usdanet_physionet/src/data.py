import os
import re
import glob
import hashlib
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional

import numpy as np
import mne
import torch
from torch.utils.data import Dataset
from scipy.signal import iirnotch, filtfilt, butter, sosfiltfilt

mne.set_log_level("WARNING")

CLASS_NAMES = ["left", "right", "feet"]
CLASS_TO_ID = {"left": 0, "right": 1, "feet": 2}

# Imagery runs according to the PhysioNet run-specific annotation convention.
UNILATERAL_IMAGERY_RUNS = {4: {"T1": "left", "T2": "right"},
                            8: {"T1": "left", "T2": "right"},
                            12: {"T1": "left", "T2": "right"}}
BILATERAL_IMAGERY_RUNS = {6: {"T2": "feet"}, 10: {"T2": "feet"}, 14: {"T2": "feet"}}


def _subject_id_from_path(path: str) -> Optional[str]:
    m = re.search(r"S(\d{3})", os.path.basename(path).upper())
    return f"S{m.group(1)}" if m else None


def _run_from_path(path: str) -> Optional[int]:
    m = re.search(r"R(\d{2})", os.path.basename(path).upper())
    return int(m.group(1)) if m else None


def discover_edf(data_root: str) -> Dict[str, Dict[int, str]]:
    files = glob.glob(os.path.join(data_root, "**", "*.edf"), recursive=True)
    out: Dict[str, Dict[int, str]] = {}
    for p in files:
        sid, run = _subject_id_from_path(p), _run_from_path(p)
        if sid and run:
            out.setdefault(sid, {})[run] = p
    return dict(sorted(out.items()))


def cache_key(cfg: dict, edf_path: str) -> str:
    s = "|".join(map(str, [edf_path, os.path.getsize(edf_path), cfg["sampling_rate"],
                            cfg["bandpass_low"], cfg["bandpass_high"], cfg["notch"],
                            cfg["reference"], cfg["tmin"], cfg["window_seconds"]]))
    return hashlib.sha1(s.encode()).hexdigest()[:16]


def _extract_annotations(raw: mne.io.BaseRaw, run: int):
    events, event_id = mne.events_from_annotations(raw, verbose=False)
    # PhysioNet EDF annotations are usually T0/T1/T2; retain only T1/T2 relevant to the run.
    id_to_desc = {v: k for k, v in event_id.items()}
    mapping = {}
    if run in UNILATERAL_IMAGERY_RUNS:
        for k, cls in UNILATERAL_IMAGERY_RUNS[run].items():
            if k in event_id:
                mapping[event_id[k]] = CLASS_TO_ID[cls]
    elif run in BILATERAL_IMAGERY_RUNS:
        if "T2" in event_id:
            mapping[event_id["T2"]] = CLASS_TO_ID["feet"]
    selected = []
    for e in events:
        code = int(e[2])
        if code in mapping:
            selected.append((int(e[0]), int(mapping[code])))
    return selected


def preprocess_array(data: np.ndarray, sfreq: float, cfg: dict) -> np.ndarray:
    # data [C, T]
    data = data.astype(np.float32, copy=False)
    # Remove channel DC then average-reference.
    data = data - np.mean(data, axis=1, keepdims=True)
    if cfg.get("reference", "average") == "average":
        data = data - np.mean(data, axis=0, keepdims=True)

    nyq = sfreq / 2.0
    lo = cfg["bandpass_low"] / nyq
    hi = min(cfg["bandpass_high"] / nyq, 0.99)
    sos = butter(4, [lo, hi], btype="bandpass", output="sos")
    data = sosfiltfilt(sos, data, axis=-1).astype(np.float32)

    notch = float(cfg.get("notch", 0.0) or 0.0)
    if notch > 0 and notch < nyq:
        b, a = iirnotch(notch / (sfreq / 2.0), Q=30.0)
        data = filtfilt(b, a, data, axis=-1).astype(np.float32)
    return data


def robust_subject_scale(X: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    # Fit per-channel robust z-score on training EEG only.
    med = np.median(X, axis=(0, 2), keepdims=True)
    q25 = np.percentile(X, 25, axis=(0, 2), keepdims=True)
    q75 = np.percentile(X, 75, axis=(0, 2), keepdims=True)
    scale = np.maximum(q75 - q25, 1e-6)
    return ((X - med) / scale).astype(np.float32), med.astype(np.float32), scale.astype(np.float32)


def apply_subject_scale(X: np.ndarray, med: np.ndarray, scale: np.ndarray) -> np.ndarray:
    return ((X - med) / np.maximum(scale, 1e-6)).astype(np.float32)


@dataclass
class SubjectData:
    X: np.ndarray
    y: np.ndarray
    subject_ids: np.ndarray
    meta: List[dict]


def load_subject(subject_id: str, run_paths: Dict[int, str], cfg: dict, cache_dir: str) -> SubjectData:
    os.makedirs(cache_dir, exist_ok=True)
    xs, ys, meta = [], [], []
    target_len = int(round(cfg["window_seconds"] * cfg["sampling_rate"]))
    start_offset = int(round(cfg["tmin"] * cfg["sampling_rate"]))

    for run, path in sorted(run_paths.items()):
        if run not in UNILATERAL_IMAGERY_RUNS and run not in BILATERAL_IMAGERY_RUNS:
            continue
        key = cache_key(cfg, path)
        cache_file = os.path.join(cache_dir, f"{subject_id}_R{run:02d}_{key}.npz")
        if os.path.exists(cache_file):
            z = np.load(cache_file, allow_pickle=True)
            xr, yr = z["X"], z["y"]
            xs.append(xr); ys.append(yr)
            meta.extend(z["meta"].tolist())
            continue

        raw = mne.io.read_raw_edf(path, preload=True, stim_channel=None, verbose=False)
        raw.pick([ch for ch in raw.ch_names if ch.upper() not in {"EDF ANNOTATIONS", "ANNOTATIONS"}])
        if raw.info["sfreq"] != cfg["sampling_rate"]:
            raw.resample(cfg["sampling_rate"], npad="auto", verbose=False)
        data = raw.get_data().astype(np.float32)
        data = preprocess_array(data, raw.info["sfreq"], cfg)
        events = _extract_annotations(raw, run)
        Xr, yr, mr = [], [], []
        for sample, label in events:
            start = sample + start_offset
            stop = start + target_len
            if start < 0 or stop > data.shape[1]:
                continue
            epoch = data[:, start:stop]
            if epoch.shape[1] == target_len:
                Xr.append(epoch)
                yr.append(label)
                mr.append({"subject": subject_id, "run": run, "sample": sample, "label": label, "file": path})
        if Xr:
            xr = np.stack(Xr).astype(np.float32)
            yr = np.asarray(yr, dtype=np.int64)
            np.savez_compressed(cache_file, X=xr, y=yr, meta=np.asarray(mr, dtype=object))
            xs.append(xr); ys.append(yr); meta.extend(mr)

    if not xs:
        raise RuntimeError(f"No 3-class imagery epochs found for {subject_id}")
    X = np.concatenate(xs, axis=0)
    y = np.concatenate(ys, axis=0)
    if X.shape[1] != cfg["num_channels"]:
        raise ValueError(f"{subject_id}: expected {cfg['num_channels']} EEG channels, got {X.shape[1]}")
    return SubjectData(X=X, y=y, subject_ids=np.asarray([subject_id] * len(y)), meta=meta)


class EEGDataset(Dataset):
    def __init__(self, X, y, augment=False, cfg=None):
        self.X = torch.from_numpy(X.astype(np.float32))
        self.y = torch.from_numpy(y.astype(np.int64))
        self.augment = augment
        self.cfg = cfg or {}

    def __len__(self): return len(self.y)

    def _aug(self, x):
        if np.random.rand() < 0.5:
            x = x + torch.randn_like(x) * float(self.cfg.get("noise_std", 0.01))
        if np.random.rand() < 0.5:
            lo, hi = self.cfg.get("amplitude_scale_min", .9), self.cfg.get("amplitude_scale_max", 1.1)
            x = x * float(np.random.uniform(lo, hi))
        p = float(self.cfg.get("channel_dropout_p", 0.1))
        if p > 0:
            mask = torch.rand(x.shape[0]) < p
            if mask.any(): x[mask] = 0
        if np.random.rand() < float(self.cfg.get("time_mask_p", .2)):
            mx = min(int(self.cfg.get("time_mask_max", 24)), x.shape[-1] // 4)
            w = np.random.randint(1, max(2, mx + 1))
            s = np.random.randint(0, x.shape[-1] - w + 1)
            x[:, s:s+w] = 0
        return x

    def __getitem__(self, i):
        x = self.X[i].clone()
        if self.augment:
            x = self._aug(x)
        return x, self.y[i]
