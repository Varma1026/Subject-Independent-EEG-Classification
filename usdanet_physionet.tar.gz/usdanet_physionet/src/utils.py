import os
import random
import json
import numpy as np
import torch


def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = True


def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def save_json(obj, path: str):
    def convert(x):
        if isinstance(x, (np.integer,)): return int(x)
        if isinstance(x, (np.floating,)): return float(x)
        if isinstance(x, np.ndarray): return x.tolist()
        if isinstance(x, dict): return {k: convert(v) for k, v in x.items()}
        if isinstance(x, (list, tuple)): return [convert(v) for v in x]
        return x
    with open(path, "w", encoding="utf-8") as f:
        json.dump(convert(obj), f, indent=2)


def ramp_up(epoch_zero_based: int, total_epochs: int, start_epoch: int = 0):
    if epoch_zero_based < start_epoch:
        return 0.0
    p = (epoch_zero_based - start_epoch + 1) / max(1, total_epochs - start_epoch)
    p = float(np.clip(p, 0.0, 1.0))
    return 2.0 / (1.0 + np.exp(-10.0 * p)) - 1.0


def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
