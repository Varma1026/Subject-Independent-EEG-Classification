import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Function


class GradientReversal(Function):
    @staticmethod
    def forward(ctx, x, lambd):
        ctx.lambd = lambd
        return x.view_as(x)
    @staticmethod
    def backward(ctx, grad_output):
        return -ctx.lambd * grad_output, None


def grl(x, lambd):
    return GradientReversal.apply(x, float(lambd))


class ConvBNAct(nn.Module):
    def __init__(self, c1, c2, k=7, dilation=1, p=.1):
        super().__init__()
        pad = ((k - 1) // 2) * dilation
        self.block = nn.Sequential(
            nn.Conv1d(c1, c2, k, padding=pad, dilation=dilation, bias=False),
            nn.BatchNorm1d(c2),
            nn.GELU(),
            nn.Dropout(p),
        )
    def forward(self, x): return self.block(x)


class MultiScaleTemporal(nn.Module):
    def __init__(self, in_ch, out_ch, p=.2):
        super().__init__()
        branch = out_ch // 4
        self.branches = nn.ModuleList([
            nn.Sequential(nn.Conv1d(in_ch, branch, 3, padding=1, bias=False), nn.BatchNorm1d(branch), nn.GELU()),
            nn.Sequential(nn.Conv1d(in_ch, branch, 7, padding=3, bias=False), nn.BatchNorm1d(branch), nn.GELU()),
            nn.Sequential(nn.Conv1d(in_ch, branch, 15, padding=7, bias=False), nn.BatchNorm1d(branch), nn.GELU()),
            nn.Sequential(nn.Conv1d(in_ch, branch, 31, padding=15, bias=False), nn.BatchNorm1d(branch), nn.GELU()),
        ])
        self.proj = nn.Sequential(nn.Conv1d(branch*4, out_ch, 1, bias=False), nn.BatchNorm1d(out_ch), nn.GELU(), nn.Dropout(p))
    def forward(self, x): return self.proj(torch.cat([b(x) for b in self.branches], dim=1))


class LearnableSpectral(nn.Module):
    def __init__(self, channels, bands=6, width=9, p=.2):
        super().__init__()
        self.depth = nn.Conv1d(channels, channels * bands, kernel_size=width, padding=width//2,
                               groups=channels, bias=False)
        self.mix = nn.Conv1d(channels * bands, channels, 1, bias=False)
        self.bn = nn.BatchNorm1d(channels)
        self.act = nn.GELU()
        self.drop = nn.Dropout(p)
    def forward(self, x): return self.drop(self.act(self.bn(self.mix(self.depth(x)))))


class ChannelAttention(nn.Module):
    def __init__(self, channels, reduction=8):
        super().__init__()
        hid = max(4, channels // reduction)
        self.mlp = nn.Sequential(nn.Linear(channels, hid), nn.GELU(), nn.Linear(hid, channels))
    def forward(self, x):
        z = x.mean(dim=-1)
        a = torch.sigmoid(self.mlp(z)).unsqueeze(-1)
        return x * a


class ResidualTCN(nn.Module):
    def __init__(self, channels, dilation, p=.2):
        super().__init__()
        self.c1 = ConvBNAct(channels, channels, 7, dilation=dilation, p=p)
        self.c2 = ConvBNAct(channels, channels, 7, dilation=dilation, p=p)
    def forward(self, x): return x + self.c2(self.c1(x))


class USDAEncoder(nn.Module):
    def __init__(self, num_channels=64, stem=32, temp=32, fusion=64, emb=128, heads=4, layers=3, ffn=256, dropout=.2):
        super().__init__()
        self.temporal = MultiScaleTemporal(num_channels, temp, dropout)
        self.spectral = LearnableSpectral(num_channels, bands=6, p=dropout)
        self.spec_proj = nn.Sequential(nn.Conv1d(num_channels, temp, 1, bias=False), nn.BatchNorm1d(temp), nn.GELU())
        self.fuse = nn.Sequential(nn.Conv1d(2*temp, fusion, 1, bias=False), nn.BatchNorm1d(fusion), nn.GELU())
        self.spatial = nn.Conv1d(fusion, fusion, kernel_size=1, bias=False)
        self.attn = ChannelAttention(fusion)
        self.tcn = nn.Sequential(ResidualTCN(fusion, 1, dropout), ResidualTCN(fusion, 2, dropout), ResidualTCN(fusion, 4, dropout))
        enc_layer = nn.TransformerEncoderLayer(d_model=fusion, nhead=heads, dim_feedforward=ffn,
                                               dropout=dropout, batch_first=True, norm_first=True, activation="gelu")
        self.transformer = nn.TransformerEncoder(enc_layer, num_layers=layers)
        self.pool_gate = nn.Sequential(nn.Linear(fusion, fusion//2), nn.GELU(), nn.Linear(fusion//2, 1))
        self.out = nn.Sequential(nn.Linear(fusion, emb), nn.LayerNorm(emb))

    def forward(self, x):
        # x: B,C,T
        t = self.temporal(x)
        s = self.spec_proj(self.spectral(x))
        h = self.fuse(torch.cat([t, s], dim=1))
        h = self.spatial(h)
        h = self.attn(h)
        h = self.tcn(h)
        seq = h.transpose(1, 2)
        seq = self.transformer(seq)
        a = torch.softmax(self.pool_gate(seq).squeeze(-1), dim=-1).unsqueeze(-1)
        pooled = (seq * a).sum(dim=1)
        z = F.normalize(self.out(pooled), dim=-1)
        return z


class USDAClassifier(nn.Module):
    def __init__(self, num_channels, num_classes, num_domains, **kwargs):
        super().__init__()
        self.encoder = USDAEncoder(num_channels=num_channels, **kwargs)
        emb = kwargs.get("emb", 128)
        self.class_head = nn.Sequential(nn.Linear(emb, 64), nn.GELU(), nn.Dropout(kwargs.get("dropout", .2)), nn.Linear(64, num_classes))
        self.domain_head = nn.Sequential(nn.Linear(emb, 64), nn.GELU(), nn.Dropout(kwargs.get("dropout", .2)), nn.Linear(64, num_domains))
        self.prototypes = nn.Parameter(F.normalize(torch.randn(num_classes, emb), dim=-1))

    def forward(self, x, domain_lambda=0.0):
        z = self.encoder(x)
        logits = self.class_head(z)
        dlogits = self.domain_head(grl(z, domain_lambda)) if domain_lambda > 0 else self.domain_head(z.detach())
        return {"z": z, "logits": logits, "domain_logits": dlogits}
