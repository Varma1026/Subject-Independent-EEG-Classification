# USDA-Net: Subject-Independent 3-Class PhysioNet EEGMI

This project implements the proposed Universal Subject-Domain Adaptive Network (USDA-Net) for strict subject-independent 3-class motor-imagery EEG classification on PhysioNet EEGMMIDB.

## Classes
- 0: left hand/fist imagery
- 1: right hand/fist imagery
- 2: both-feet imagery

## PhysioNet run selection
The dataset has 14 runs/subject. Motor imagery is in runs 4, 8, 12 for left/right fist and runs 6, 10, 14 for bilateral fist/feet imagery. T1/T2 meanings depend on the run. We therefore use:
- Runs 4, 8, 12: T1 -> LEFT, T2 -> RIGHT
- Runs 6, 10, 14: T2 -> FEET; T1 (both fists) is excluded

This matches the published PhysioNet documentation.

## Folder layout
Set `DATA_ROOT` to the directory containing the subject folders, e.g.

```
DATA_ROOT/
  S001/
    S001R01.edf
    ...
    S001R14.edf
  S002/
    ...
```

The loader also recursively discovers `.edf` files named like `S001R04.edf`, so a flat directory is acceptable.

## Install

```bash
pip install -r requirements.txt
```

## Run a smoke test

```bash
python train.py --config configs/physionet.yaml --max_subjects 4 --epochs 3
```

## Full LOSO

```bash
python train.py --config configs/physionet.yaml --epochs 60
```

For the first complete experiment, run the code exactly as configured and preserve the resulting per-subject CSV. Do not report an 80% result unless it is actually obtained under LOSO.

## Optional unlabeled target adaptation
The implementation contains a separate entropy-minimization adaptation routine. It is disabled for strict LOSO evaluation and should only be reported as a separate transductive experiment.
